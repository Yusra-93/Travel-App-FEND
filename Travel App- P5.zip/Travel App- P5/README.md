# Traveling App Project

In this project we created a a traveling app, which the user can enter his/her destination city and the date of traveling, and he/she will get:

1- The city's temperature of his arriving date.
2- An image for the destination city.
3- The country name of the destination city.



## The components of the project's folders:

1-  Src > Client Folder

Which has 3 main folders:
- Styles
Which has all scss code/ styling code.

- Views
Which has the html code for our web page.

- Js
Which has the JavaScript code, that responisible for our web page dynamic.


2- Src > Server Folder

Which has the server setup and the web routers.


3- __test__ folder:

which has the tests code for: 
- The express server.
- Application javascript.


## Main Commands to run the app:

- To run the dev mode:
npm run build-dev

- To run the server:
npm run start

- To run the prod mode:
npm run build-prod

- To run the test:
npm run test


# -------------------------------------------------------- #
# NOTE FOR THE REVIEWER:

The one option I added from (Extend your Project Further - Roadmap/Strategy) is:

- Pulling in an image for the country from Pixabay API when the entered location brings up no results.

# -------------------------------------------------------- #