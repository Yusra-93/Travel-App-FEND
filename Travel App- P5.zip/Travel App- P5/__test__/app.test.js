
// Here we will test (handleSubmit) function from app.js, if it is working/ defined or not

import { handleSubmit } from "../src/client/js/app";


describe("Testing the submit functionality", () => { 
	
    test("Testing the handleSubmit() function", () => {
           expect(handleSubmit).toBeDefined();
})});

