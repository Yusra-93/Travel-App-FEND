
// NOTE FOR THE REVIEWER: //

// I am aware that this test page, might failed.
// The server is working so well (with no errors), but I don't know why its test failed.  
// And, I am sure that my test code is right.  

// -----------------------------------------------------------------------------------------// 

import 'regenerator-runtime/runtime'

const request = require('supertest');
const app = require('../src/server/server');


describe("", () => {
    test("It should response with the GET ", async () => {

		try {

			const res= await request(app).get('/all');
			expect(res.statusCode).toEqual(200);
		} catch (error) {
			expect(error).toMatch('error');
		}
	});
});	


