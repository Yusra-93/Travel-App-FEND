
const path = require('path');

// Require Express to run server and routes
const express = require('express');

// Start up an instance of app
const app = express();

/* Dependencies */
const bodyParser = require('body-parser');

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('dist'));

console.log(__dirname)

// Setup Server

const port = 8000;

const server = app.listen(port, listening);

function listening(){
	console.log(`server running on localhost: ${port}`);
}



//-------------------------------------------------------------------------//

// Router:

// Setup empty JS object to act as endpoint for all routes
const projectData = {};

// GET route

app.get('/all', function (req, res) {
	res.sendFile('dist/index.html');
	//res.sendFile(path.resolve('src/client/views/index.html'))
	//res.send(projectData)
});


// POST route

app.post('/add', function (req, res) {
	projectData['to_city'] = req.body.to_city;
    projectData['temperature'] = req.body.temperature;
	projectData['date'] = req.body.date;
	projectData['city_image']  = req.body.city_image;
	projectData['country_name']  = req.body.country_name;

    res.send(projectData);
});

//-------------------------------------------------------------------------//

module.exports = app;

