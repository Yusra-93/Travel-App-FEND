
// We declare this veriable, for the data that we want to post
const inputs = {};


//-----------------------------------------------------------------------//

/* Function to POST data */

async function postData(inputs) {
    console.log(inputs)
    const response = await fetch('http://localhost:8000/add', {
        
        method: "POST",
        credentials: 'same-origin',
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(inputs),
    });
    
    try {
        const newData = await response.json();
        return newData
	}catch(error) {
	  console.log("error", error);
	  
	}
}

//-----------------------------------------------------------------------//

// In this function we will retrieve the data from the APIs and store them in (inputs), 
// to post them on (postData), then update the UI.

function handleSubmit(event) {
    event.preventDefault(); 


// First, we will get (the traveling date + the destination city) that entered by the user.

    inputs['to_city'] = document.getElementById('city').value;
    inputs['date'] = document.getElementById('date').value;
    

    try {
        // Here we will fetch for the destination city data
        geonames(inputs['to_city'])
        
        // Now, we will get (lat,lng and countryName) and save them in geonames_data
            .then((geonames_data) => {
                
                const lat = geonames_data.geonames[0].lat;
                const lng = geonames_data.geonames[0].lng;
                inputs['country_name'] = geonames_data['geonames'][0]['countryName'];
                
                

        //Here, we will return lat,lng from Weatherbit that matched in geonames
                return Weatherbit(lat, lng);
            })
        // Now, we will get the temperature and save it in Weatherbit_data

            .then((Weatherbit_data) => {
                
                inputs['temperature'] = Weatherbit_data['data'][0]['temp'];
                

        //Here, we will return the city image 

                return image(inputs['to_city']);

            })
        // Now, we will get the city image and save it in image_data

            .then((image_data) => {
                if (image_data['hits'].length > 0) {
                    inputs['city_image'] = image_data['hits'][0]['webformatURL'];
                }
        // Here, we will return all the data and store them in (inputs),to post them on (postData)
                return postData(inputs);
            })
            

        // Now, we will take all the data to update the DOM with them
            .then((data) => {
                updateUI(data);
            })
            
    } catch (error) {
        console.log("error", error)
    }
}


//--------------------------------------------------------------------------------------------------------
// Geonames API 
// In this API, we will fetch for the city data

async function geonames(to_city) {
	const res = await fetch(`http://api.geonames.org/search?q=${to_city}&username=yusra&type=json`);
	
    try {
		const data = await res.json();
		return data;
        
    } catch (error) {
        console.log("error", error);
    }
}




//-------------------------------------------------------------------------------------------------------

// Weatherbit API 
// In this API, we will fetch for the (lat, lng) 


async function Weatherbit(lat, lng) {

    // First, we will get the traveling date that intered by the user.
    const traveling_date = document.getElementById('date').value;
	
	// Second, we will create a new date instance dynamically with JS
    let d = new Date();
    let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

    
    // Third, we will check if the date entered by the user, is an upcoming date or not
    let res;
    if (traveling_date < newDate) {

		res= console.log("please, enter an upcoming date")
    } else {
		res = await fetch(`https://api.weatherbit.io/v2.0/forecast/daily?lat=${lat}&lon=${lng}&key=6c43da9d861a4e658da2fd5d79b6ae87`);
		
    }

    try {
		const data = await res.json();
		return data;
		
    } catch (error) {
        console.log("error", error)
    }
}


//------------------------------------------------------------------------------------------------
// Pixabay API
// In this API, we will fetch for the city image 


async function image(to_city_2) {
    
    const res = await fetch(`https://pixabay.com/api/?key=19793358-296b0dccb579de94854ded974&q=${to_city_2}&image_type=photo`);
    
    try {
		const data = await res.json();
        return data;
        
    } catch (error) {
        console.log("error", error)
    }
}

//------------------------------------------------------------------------------------------------



// Updating UI function, to show the data we retrieved from our app on the DOM:

function updateUI(data) {

    const date_of_traveling = document.getElementById('date_of_traveling');
    const image = document.getElementById('image');
    const temperature = document.getElementById('temperature');
    const country = document.getElementById('country');


    
    
    image.setAttribute('src', data.city_image);
    date_of_traveling.innerHTML = `<p> Date of traveling: ${data.date}</p>`;
    temperature.innerHTML = `<p>The Temperature will be: ${data.temperature}</p>`;
    country.innerHTML = `<p>You Are Traveling to: ${data.country_name}</p>`;


}

//------------------------------------------------------------------------------------------------

export { handleSubmit, geonames, Weatherbit, image, postData, updateUI }

