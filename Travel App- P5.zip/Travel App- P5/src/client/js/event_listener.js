import  {handleSubmit} from "./app";



const addEventListener = document.getElementById("search").addEventListener("click", handleSubmit);



export {addEventListener}

